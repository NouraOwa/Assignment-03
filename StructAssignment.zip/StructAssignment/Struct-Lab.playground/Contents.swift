import Foundation
/*:
 ## Struct Lab - Tuwaiq Bootcamp

 Create a struct called Book that contains the following properties:

 - title: a String representing the title of the book
 - author: a String representing the author of the book
 - pages: an integer representing the number of pages in the book
 - topic: a String representing the topic or genre of the book (e.g. Computer Science, Programming, Self-Development, etc.)
 
 */
struct Book{
    var title: String
    var author: String
    var pages: Int
    var topic: String
    
    init(title: String, author: String, pages: Int, topic: String){
        self.title = title
        self.author = author
        self.pages = pages
        self.topic = topic
    }
}
/*:
 Create an array of type Book and populate it with at least 3 books using a loop.
 */
let book1 = (Book(title: "How to study", author: "George Swian", pages: 159, topic: "Educational Book"))
let book2 = (Book (title: "The Wind in the Willows", author: "Kenneth Grahame", pages: 342, topic: "Novel"))
let book3 = (Book (title: "The Old Man and the Sea", author: "Ernest Hemingway", pages: 80, topic: "Novel"))

let books = [book1, book2, book3]

var booksArray :[Book] = []
    for _ in books{
        booksArray.append(contentsOf: books)
}
/*:
 Then, write a function called printBooksInTopic that takes two arguments: the array of books and a topic as a String. The function should print out the title and author of each book in the array that matches the specified topic.
 */

// Example usage:
// printBooksInTopic(books, topic: "Programming")

// Example usage:
//printBooksInTopic(books, topic: "Programming")

//Output
/*
 Clean Code: A Handbook of Agile Software Craftsmanship by Robert C. Martin
 Cracking the Coding Interview: 189 Programming Questions and Solutions by Gayle Laakmann McDowell
 */
func printBooksInTopic(booksArray: [Book], topic: String){
    print("\(book1.title) : \(book1.topic), by \(book1.author)")
    print("\(book2.title) : \(book2.topic), by \(book2.author)")
    print("\(book3.title) : \(book3.topic), by \(book3.author)")
}
printBooksInTopic(booksArray: books, topic: "topic")
